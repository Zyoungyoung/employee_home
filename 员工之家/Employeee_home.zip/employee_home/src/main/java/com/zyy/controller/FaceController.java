package com.zyy.controller;


import com.baidu.aip.face.AipFace;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyy.mapper.UserMapper;
import com.zyy.service.Sample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.Map;

@Controller
public class FaceController {
    public static final String APP_ID = "27350116";
    public static final String API_KEY = "qe0g3Msb30YufIPX5sXvXpY6";
    public static final String SECRET_KEY = "2ybzoO3ciuaSr8PgZOFYEbSmO2UVwFsr";


    @Autowired
    private UserMapper mapper;

    @RequestMapping("/snap_data")
//    @ResponseBody用于ajax发送数据后 是否返还jsp，要是返还，必须要有
   @ResponseBody
    public String excute(@RequestParam("imgData") String base64string) {
//        删除开头得到完成的base64的码
        String base64 = base64string.split(",")[1];
        AipFace client = null;
//        初始化一个cilent
        try {
            client = new AipFace(APP_ID, API_KEY, SECRET_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }

//        这是一个人脸对比接口
        Sample sample = new Sample();

        double score = sample.contrastFace(client, base64);
        System.out.println("照片对比得分为:" + score);
//        对照片得分进行对比
        Map<String,String> result = new HashMap<>();
        String end = null;
        if (score > 80.0) {
            System.out.println("人脸识别成功!");
            result.put("message","success");
            end = "Manager";
        }else{
            System.out.println("人脸识别失败！");
            result.put("message","error");
        }
        ObjectMapper om = new ObjectMapper();
        String resultj = "";
        try {
            resultj = om.writeValueAsString(result);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        System.out.println(resultj);
        return resultj;

    }
}
