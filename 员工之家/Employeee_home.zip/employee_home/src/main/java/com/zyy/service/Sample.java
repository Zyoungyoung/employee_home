package com.zyy.service;

import com.baidu.aip.face.AipFace;
import com.baidu.aip.face.MatchRequest;
import com.baidu.aip.util.Base64Util;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Objects;

public class Sample {
    //设置APPID/AK/SK
    public static final String APP_ID = "27350116";
    public static final String API_KEY = "qe0g3Msb30YufIPX5sXvXpY6";
    public static final String SECRET_KEY = "2ybzoO3ciuaSr8PgZOFYEbSmO2UVwFsr";

    public static void main(String[] args) {
        // 初始化一个AipFace
        AipFace client = new AipFace(APP_ID, API_KEY, SECRET_KEY);

        // 可选：设置网络连接参数
        client.setConnectionTimeoutInMillis(2000);
        client.setSocketTimeoutInMillis(60000);

////        这是一个人脸对比接口,本地测试类
//        Sample sample = new Sample();
//        sample.contrastFace2(client);
//
    }
////这是一个测试接口类
//    public void contrastFace2(AipFace client ) {
//
//        String image1 = ImageToBase64("C:\\employee_home\\src\\main\\java\\com\\zyy\\service\\phone.png");
//        String image2 = ImageToBase64("C:\\employee_home\\src\\main\\java\\com\\zyy\\service\\phone.png");
////        ImageToBase64是一个将img转化为base64的方法
//
//        // image1/image2也可以为url或facetoken, 相应的imageType参数需要与之对应。
//
//        MatchRequest req1 = new MatchRequest(image1, "BASE64");
//        MatchRequest req2 = new MatchRequest(image2, "BASE64");
//        ArrayList<MatchRequest> requests = new ArrayList<MatchRequest>();
//        requests.add(req1);
//        requests.add(req2);
//
//
////        人脸对比的应用在client中
//        JSONObject res = client.match(requests);
////        toString(2)是返回对比的数组中的前两个,不然会是一个很长很长的字符串
//        System.out.println(res.toString(2));
////获取socre得分
//        JSONObject obj = res.getJSONObject("result");
//        Double score = obj.getDouble("score");
//        System.out.println("score的分数为:"+score);
//
//    }


//    定义一个人脸对比接口   这是一个调用方法(其中图片类型必须转换为base64格式)
    public double contrastFace(AipFace client, String base64Img ) {

        String image1 = ImageToBase64("C:\\employee_home\\src\\main\\java\\com\\zyy\\service\\phone.png");
        String image2 = base64Img;
//        ImageToBase64是一个将img转化为base64的方法
//        String image2 = ImageToBase64("C:\\employee_home\\src\\main\\java\\com\\zyy\\service\\phone.png");

        // image1/image2也可以为url或facetoken, 相应的imageType参数需要与之对应。

        MatchRequest req1 = new MatchRequest(image1, "BASE64");
        MatchRequest req2 = new MatchRequest(image2, "BASE64");
        ArrayList<MatchRequest> requests = new ArrayList<MatchRequest>();
        requests.add(req1);
        requests.add(req2);


//        人脸对比的应用在client中
        JSONObject res = client.match(requests);
//        获取成绩对比前两个元素的数组
        //System.out.println(res.toString(2));

//        获取socre得分
        JSONObject obj = res.getJSONObject("result");
        Double score = obj.getDouble("score");
       // System.out.println("score的分数为:"+score);

        return score;
    }




//    这是一个将普通图片转换为base64的方法,用于发送到百度的接口进行人脸对比
    private static String ImageToBase64(String imgPath) {
        byte[] data = null;
        // 读取图片字节数组
        try {
            InputStream in = new FileInputStream(imgPath);
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 对字节数组Base64编码
        Base64Util encoder = new Base64Util();
        // 返回Base64编码过的字节数组字符串
        String s = encoder.encode(Objects.requireNonNull(data));
       // System.out.println("本地图片转换Base64:" + s);
        return s;
    }
}





