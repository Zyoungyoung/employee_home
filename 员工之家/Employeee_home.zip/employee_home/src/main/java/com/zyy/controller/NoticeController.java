package com.zyy.controller;


import com.zyy.entity.Job;
import com.zyy.entity.Notice;
import com.zyy.mapper.NoticeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Controller
public class NoticeController {


    @Autowired
    private NoticeMapper mapper;

    @RequestMapping("/notice_delete")
    public String delete(HttpServletRequest req, HttpServletResponse resp){
        Integer Id = Integer.valueOf(req.getParameter("deleteId"));
        System.out.println(Id);
        mapper.deleteByPrimaryKey(Id);
        req.setAttribute("success","删除成功！");
        return "/notice/query";
    }





    @RequestMapping("/notice_query")
    public String query(HttpServletRequest req, HttpServletResponse resp){
        List<Notice> jobs=mapper.selectAll();

        req.getSession().setAttribute("depts",jobs);
        return "/notice/query";
    }

    @RequestMapping("/notice_Add")

    public String add(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {

        String title=new String((req.getParameter("name")).getBytes("iso-8859-1"),"utf-8");
        String content=new String((req.getParameter("remark")).getBytes("iso-8859-1"),"utf-8");
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());
        String username="zyy";
//        插入数据
        Notice notice=new Notice();

        notice.setTitle(title);
        notice.setContent(content);
        notice.setCreate_date(timestamp);
        notice.setUsername(username);


//这里说是空指针，但是并没有发现值空啊
        mapper.insert(notice);
        for (Notice dept1:mapper.selectAll()
        ) {
            if (dept1.getUsername().equals(username)){

                req.setAttribute("error","恭喜您添加成功！");
                break;
            }
        }
        return "/notice/add";
    }

    @RequestMapping("/notice_update")
    public String update(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
        int Id = Integer.valueOf(req.getParameter("Id")).intValue();

        String title=new String((req.getParameter("name")).getBytes("iso-8859-1"),"utf-8");
        String content=new String((req.getParameter("remark")).getBytes("iso-8859-1"),"utf-8");
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());

        String username="zyy";
        for (Notice dept:mapper.selectAll()
        ) {
            if ("zyy".equals(dept.getUsername())){
                req.setAttribute("error","修改成功！");
                break;
            }
        }

//        插入数据
        Notice notice=new Notice();
        notice.setId(Id);
        notice.setTitle(title);
        notice.setContent(content);
        notice.setCreate_date(timestamp);
        notice.setUsername(username);

//需要做一个修改的功能
        mapper.updateByPrimaryKey(notice);
        return "/notice/update";
    }






}
