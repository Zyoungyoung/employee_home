package com.zyy.mapper;

import com.zyy.entity.Dept;
import com.zyy.entity.User;
import java.util.List;

public interface UserMapper {
    
    int deleteByPrimaryKey(Integer id);

    
    int insert(User record);

   
    User selectByPrimaryKey(Integer id);

    
    List<User> selectAll();

   
    int updateByPrimaryKey(User record);
}