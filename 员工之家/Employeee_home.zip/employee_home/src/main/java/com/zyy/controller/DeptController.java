package com.zyy.controller;


import com.zyy.entity.Dept;
import com.zyy.entity.User;
import com.zyy.mapper.DeptMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Controller
public class DeptController {

    @Autowired
    private DeptMapper mapper;


    @RequestMapping("/depart_delete")
    public String delete(HttpServletRequest req, HttpServletResponse resp){
        Integer Id = Integer.valueOf(req.getParameter("deleteId"));
        System.out.println(Id);
        mapper.deleteByPrimaryKey(Id);
        req.setAttribute("success","删除成功！");
        return "/department/query";
    }





    @RequestMapping("/depart_query")
    public String query(HttpServletRequest req, HttpServletResponse resp){
        List<Dept> depts=mapper.selectAll();
//        for (Dept dept:mapper.selectAll()
//             ) {
//            System.out.println(dept.toString());
//        }
        req.getSession().setAttribute("depts",depts);
        return "/department/query";
    }

    @RequestMapping("/depart_Add")

    public String add(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
        int Id = 1;
        String name=new String((req.getParameter("name")).getBytes("iso-8859-1"),"utf-8");
        String remark=new String((req.getParameter("remark")).getBytes("iso-8859-1"),"utf-8");
        System.out.println(name+"+"+remark);
//        插入数据
        Dept dept=new Dept();
        dept.setId(Id);
        dept.setName(name);
        dept.setRemark(remark);


//这里说是空指针，但是并没有发现值空啊
        mapper.insert(dept);
        for (Dept dept1:mapper.selectAll()
        ) {
            if (dept1.getName().equals(name)){

                req.setAttribute("error","您的用户ID为："+dept.getId());
                break;
            }
        }
        return "/department/add";
    }

    @RequestMapping("/depart_update")
    public String update(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
        int Id = Integer.valueOf(req.getParameter("Id")).intValue();
        for (Dept dept:mapper.selectAll()
        ) {
            if (dept.getId()==Id){
                req.setAttribute("error","修改成功！");
                break;
            }
        }
        String name=new String((req.getParameter("name")).getBytes("iso-8859-1"),"utf-8");
        String remark=new String((req.getParameter("remark")).getBytes("iso-8859-1"),"utf-8");


//        插入数据
        Dept dept=new Dept();
        dept.setId(Id);
        dept.setName(name);
        dept.setRemark(remark);

//需要做一个修改的功能
        mapper.updateByPrimaryKey(dept);
        return "/department/update";
    }


}
