package com.zyy.controller;


import com.zyy.entity.Employee;
import com.zyy.entity.User;
import com.zyy.mapper.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeMapper mapper;



    @RequestMapping("/employee_delete")
    public String delete(HttpServletRequest req, HttpServletResponse resp){
        Integer Id = Integer.valueOf(req.getParameter("deleteId"));
        System.out.println(Id);
        mapper.deleteByPrimaryKey(Id);
        req.setAttribute("success","删除成功！");
        return "/employee/query";
    }



    @RequestMapping("/employee_query")
    //成功案例！
//    @ResponseBody
    public String query(HttpServletRequest req, HttpServletResponse resp){
        List<Employee> users=mapper.selectAll();

//        遍历数组
//        for (User user:users
//             ) {
//            System.out.println(user.toString());
//        }
        //req.setAttribute("users",users);
        req.getSession().setAttribute("users",users);
        //req.getRequestDispatcher("employee/query.jsp").forward(req,resp);
        return "/employee/query";

    }


    @RequestMapping("/employee_Add")
    public String add(HttpServletRequest req, HttpServletResponse resp){
        int Id =1;
        String name = req.getParameter("name");
        System.out.println(name);
            int dept_Id = 1;
            System.out.println(dept_Id);
            int job_Id = 2;


            String card_Id = req.getParameter("card_Id");
            String address = req.getParameter("address");
            String post_code = req.getParameter("post_code");
            String tel = req.getParameter("tel");
            String phone = req.getParameter("phone");
            String qq = req.getParameter("qq");
            String email = req.getParameter("email");
            int sex = 1;
            String party = req.getParameter("party");
//        new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(信息) 时间格式转换

//        当前时间
            Date birthday = new Date();
            try {
                birthday = new SimpleDateFormat("yyyy-MM-dd").parse(req.getParameter("birthday"));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String race = req.getParameter("race");
            String education = req.getParameter("education");
            String speciality = req.getParameter("speciality");
            String hobby = req.getParameter("hobby");
            String remark = req.getParameter("remark");
            Date date = new Date();
            Timestamp create_date = new Timestamp(date.getTime());

            Employee employee = new Employee();
            employee.setId(Id);
            employee.setCreate_date(create_date);
            employee.setAddress(address);
            employee.setBirthday(birthday);
            employee.setCard_Id(card_Id);
            employee.setDept_Id(dept_Id);
            employee.setCreate_date(create_date);
            employee.setEducation(education);
            employee.setEmail(email);
            employee.setHobby(hobby);
            employee.setJob_Id(job_Id);
            employee.setName(name);
            employee.setParty(party);
            employee.setPhone(phone);
            employee.setPost_code(post_code);
            employee.setQq(qq);
            employee.setRace(race);
            employee.setRemark(remark);
            employee.setSex(sex);
            employee.setSpeciality(speciality);
            employee.setTel(tel);

            mapper.insert(employee);
            for (Employee users : mapper.selectAll()
            ) {
                if (users.getName().equals(name)) {

                    req.setAttribute("error", "新建用户ID为：" + users.getId());
                    break;
                }
            }


            return "employee/add";





}
}
