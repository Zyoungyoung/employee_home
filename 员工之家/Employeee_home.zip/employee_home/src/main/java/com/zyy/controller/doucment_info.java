package com.zyy.controller;


import com.zyy.entity.Doucment;
import com.zyy.entity.User;
import com.zyy.mapper.DoucmentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Controller
public class doucment_info {

    @Autowired
    private DoucmentMapper mapper;

    @RequestMapping("/docu_query")
    public String query(HttpServletRequest req, HttpServletResponse resp){

        List<Doucment> doucments=mapper.selectAll();

        req.getSession().setAttribute("users",doucments);

        return "document/query";
    }

    @RequestMapping("/docu_delete")
    public String delete(HttpServletRequest req,HttpServletResponse resp){
        Integer Id = Integer.valueOf(req.getParameter("deleteId"));
        System.out.println(Id);
        mapper.deleteByPrimaryKey(Id);
        req.setAttribute("success","删除成功！");
        return "/document/query";

    }
    @RequestMapping("/docu_Add")
    public String add(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
        int Id = 1;
        String name=new String((req.getParameter("name")).getBytes("iso-8859-1"),"utf-8");
        String remark=new String((req.getParameter("remark")).getBytes("iso-8859-1"),"utf-8");

//        获取当前创号日期
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());

        String faceurl="blank";//面部地址



//        插入数据
        Doucment user=new Doucment();
        user.setId(Id);
        user.setTitle(name);
        user.setRemark(remark);
        user.setUser_Id(1);
        user.setCreate_date(timestamp);
        user.setFilename(faceurl);


//这里说是空指针，但是并没有发现值空啊
        mapper.insert(user);
        for (Doucment users:mapper.selectAll()
        ) {
            if (users.getTitle().equals(name)){

                req.setAttribute("error","文档编号为："+users.getId());
                break;
            }
        }
        return "/document/add";
    }


}
