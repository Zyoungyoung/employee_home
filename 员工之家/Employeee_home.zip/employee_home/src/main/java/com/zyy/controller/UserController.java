package com.zyy.controller;

import com.zyy.entity.User;
import com.zyy.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    private UserMapper mapper;

    @RequestMapping("/query")
    //成功案例！
//    @ResponseBody
    public String query(HttpServletRequest req, HttpServletResponse resp){
        List<User> users=mapper.selectAll();
//        遍历数组
//        for (User user:users
//             ) {
//            System.out.println(user.toString());
//        }
        //req.setAttribute("users",users);
        req.getSession().setAttribute("users",users);
            //req.getRequestDispatcher("employee/query.jsp").forward(req,resp);
        return "/User/query";

    }
    
    @RequestMapping("/UserAdd")

    public String add(HttpServletRequest req, HttpServletResponse resp){
        int Id = 1;
        String Loginname=req.getParameter("Loginname");
        String password=req.getParameter("password");
        int status= Integer.valueOf(req.getParameter("status")).intValue();
//        获取当前创号日期
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());
        String username = req.getParameter("username");
        String faceurl="blank";//面部地址
        String facepath="blank";//面部图片绝对路径


//        插入数据
        User user=new User();
        user.setId(Id);
        user.setLoginname(Loginname);
        user.setStatus(status);
        user.setCreatedate(timestamp);
        user.setFacepath(facepath);
        user.setFaceurl(faceurl);
        user.setUsername(username);
        user.setPassword(password);

//这里说是空指针，但是并没有发现值空啊
        mapper.insert(user);
        for (User users:mapper.selectAll()
        ) {
            if (users.getLoginname().equals(Loginname)){

                req.setAttribute("error","您的用户ID为："+users.getId());
                break;
            }
        }
        return "/User/add";
    }

    @RequestMapping("/UserUpdate")

    public String update(HttpServletRequest req, HttpServletResponse resp){
        int Id = Integer.valueOf(req.getParameter("Id")).intValue();
        for (User user:mapper.selectAll()
             ) {
            if (user.getId()==Id){
                req.setAttribute("error","修改成功！");
                break;
            }
        }
        String Loginname=req.getParameter("Loginname");
        String password=req.getParameter("password");
        int status= Integer.valueOf(req.getParameter("status")).intValue();

        String username = req.getParameter("username");


//        插入数据
        User user=new User();
        user.setId(Id);
        user.setLoginname(Loginname);
        user.setStatus(status);
        user.setUsername(username);
        user.setPassword(password);
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());
        user.setCreatedate(timestamp);

        mapper.updateByPrimaryKey(user);
        return "/User/update";
    }
    @RequestMapping("/UserDelete")

    public String delete(HttpServletRequest req, HttpServletResponse resp){
        Integer Id = Integer.valueOf(req.getParameter("deleteId"));
        System.out.println(Id);
        mapper.deleteByPrimaryKey(Id);
        req.setAttribute("success","删除成功！");
        return "/User/query";
    }
    
    

}
