package com.zyy.controller;


import com.zyy.entity.Dept;
import com.zyy.entity.Job;
import com.zyy.mapper.JobMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;

@Controller
public class JobController {

    @Autowired
    private JobMapper mapper;

    @RequestMapping("/job_delete")
    public String delete(HttpServletRequest req, HttpServletResponse resp){
        Integer Id = Integer.valueOf(req.getParameter("deleteId"));
        System.out.println(Id);
        mapper.deleteByPrimaryKey(Id);
        req.setAttribute("success","删除成功！");
        return "/job/query";
    }





    @RequestMapping("/job_query")
    public String query(HttpServletRequest req, HttpServletResponse resp){
        List<Job> jobs=mapper.selectAll();

        req.getSession().setAttribute("depts",jobs);
        return "/job/query";
    }

    @RequestMapping("/job_Add")

    public String add(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
        int Id = 1;
        String name=new String((req.getParameter("name")).getBytes("iso-8859-1"),"utf-8");

        String remark=new String((req.getParameter("remark")).getBytes("iso-8859-1"),"utf-8");
        System.out.println(name+"+"+remark);
//        插入数据
        Job job=new Job();
        job.setId(Id);
        job.setName(name);
        job.setReamark(remark);


//这里说是空指针，但是并没有发现值空啊
        mapper.insert(job);
        for (Job dept1:mapper.selectAll()
        ) {
            if (dept1.getName().equals(name)){

                req.setAttribute("error","您的用户ID为："+dept1.getId());
                break;
            }
        }
        return "/job/add";
    }

    @RequestMapping("/job_update")
    public String update(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
        int Id = Integer.valueOf(req.getParameter("Id")).intValue();
        for (Job dept:mapper.selectAll()
        ) {
            if (dept.getId()==Id){
                req.setAttribute("error","修改成功！");
                break;
            }
        }
        String name=new String((req.getParameter("name")).getBytes("iso-8859-1"),"utf-8");
        String remark=new String((req.getParameter("remark")).getBytes("iso-8859-1"),"utf-8");


//        插入数据
        Job dept=new Job();
        dept.setId(Id);
        dept.setName(name);
        dept.setReamark(remark);

//需要做一个修改的功能
        mapper.updateByPrimaryKey(dept);
        return "/job/update";
    }




}
